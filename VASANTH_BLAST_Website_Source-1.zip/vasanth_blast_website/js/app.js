const $ = (s) => document.querySelector(s);
const $$ = (s) => [...document.querySelectorAll(s)];
const STORE = 'vasanthBlastDemoAccounts';
let accounts = JSON.parse(localStorage.getItem(STORE) || '[]');

function saveAccounts(){ localStorage.setItem(STORE, JSON.stringify(accounts)); renderAccounts(); }
function toast(message){ const el=$('#toast'); el.textContent=message; el.classList.add('show'); clearTimeout(toast.timer); toast.timer=setTimeout(()=>el.classList.remove('show'),2300); }
function navigate(view){
  $$('.view').forEach(v=>v.classList.toggle('active',v.id===`${view}-view`));
  $$('.nav-item').forEach(b=>b.classList.toggle('active',b.dataset.view===view));
  const titles={overview:'Overview',accounts:'Discord Accounts',voice:'Voice Amplifier',settings:'Settings'};
  $('#page-title').textContent=titles[view]||'Overview';
}
$$('[data-view]').forEach(b=>b.addEventListener('click',()=>navigate(b.dataset.view)));
$$('[data-go]').forEach(b=>b.addEventListener('click',()=>navigate(b.dataset.go)));

function renderAccounts(){
  $('#account-count').textContent=accounts.length;
  const list=$('#account-list');
  if(!accounts.length){list.innerHTML='<div class="empty-state panel"><strong>No demo accounts yet</strong>Your locally saved profiles will appear here.<br><br>Use “Add account” to create a demo profile.</div>';return;}
  list.innerHTML=accounts.map(a=>`<article class="account-card panel"><div class="account-avatar">${escapeHtml(a.name.slice(0,2).toUpperCase())}</div><div class="account-info"><b>${escapeHtml(a.name)}</b><small>${escapeHtml(a.note||'Demo profile')} · Local only</small></div><button class="remove-btn" data-remove="${a.id}">Remove</button></article>`).join('');
  $$('[data-remove]').forEach(b=>b.addEventListener('click',()=>{accounts=accounts.filter(a=>a.id!==b.dataset.remove);saveAccounts();toast('Demo account removed');}));
}
function escapeHtml(s){return String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));}
$('#open-add').addEventListener('click',()=>$('#account-dialog').showModal());
$('#close-dialog').addEventListener('click',()=>$('#account-dialog').close());
$('#account-form').addEventListener('submit',e=>{
  e.preventDefault();
  const name=$('#account-name').value.trim(), note=$('#account-note').value.trim();
  if(!name)return;
  accounts.push({id:crypto.randomUUID?crypto.randomUUID():String(Date.now()),name,note});
  saveAccounts(); e.target.reset(); $('#account-dialog').close(); toast('Demo account added');
});

const volume=$('#volume');
function setVolume(value){
  volume.value=value; $('#volume-value').textContent=value;
  const label=value>=150?'Loud':value>=115?'Boost':'Balanced';
  $('#voice-status').textContent=label;
  $$('.preset').forEach(p=>p.classList.toggle('active',Number(p.dataset.preset)===Number(value)));
}
volume.addEventListener('input',()=>setVolume(volume.value));
$$('.preset').forEach(p=>p.addEventListener('click',()=>setVolume(p.dataset.preset)));

$('#neon-toggle').addEventListener('change',e=>document.body.classList.toggle('no-neon',!e.target.checked));
$('#avatar-toggle').addEventListener('change',e=>{$$('.account-avatar').forEach(a=>a.style.visibility=e.target.checked?'visible':'hidden');});
$('#clear-data').addEventListener('click',()=>{
  if(confirm('Remove all locally saved demo accounts?')){accounts=[];saveAccounts();toast('Demo data cleared');}
});
renderAccounts(); setVolume(100);
