# VASANTH BLAST — Website Source

A responsive purple + blue neon dashboard demo built with plain HTML, CSS and JavaScript.

## Included
- Dashboard overview and module navigation
- Discord Accounts UI with Add / Remove demo profiles
- Browser-local demo storage (`localStorage`)
- Voice Amplifier interface with volume slider and presets (visual/UI demo)
- Settings, theme toggle and clear demo data
- Responsive mobile layout

## Run locally
Open `index.html` in a modern browser. No build tools or dependencies are required.
Google Fonts are loaded from Google Fonts when internet access is available; system fonts are used as fallback.

## Discord security
This package intentionally does **not** use Discord user tokens, passwords, or session cookies.
The account manager is demo-only and stores display names/notes in the current browser.

For real Discord account linking, implement Discord OAuth2 Authorization Code flow with `state` validation and PKCE where supported. Keep client secrets on a trusted backend, request only the minimum scopes, validate the callback, and never ask users to paste tokens into the page. Configure redirect URIs in the Discord Developer Portal. This demo does not include a live OAuth integration or backend.

## Voice note
The amplifier is a front-end demonstration only. It does not access the microphone, alter Discord audio, or process live voice.
